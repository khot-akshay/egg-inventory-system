import React from 'react';
import { Box, GlobalStyles } from '@mui/material';
import ReportHeader from './ReportHeader';
import ReportInfo from './ReportInfo';
import ReportSummary, { SummaryItem } from './ReportSummary';
import ReportTable, { ColumnDef } from './ReportTable';
import { PdfTheme } from './pdfTheme';

interface CommonReportPDFProps {
  title: string;
  shopName: string;
  generatedBy: string;
  generatedOn: string;
  summary: SummaryItem[];
  columns: ColumnDef[];
  data: any[];
  totalCount: number;
  pdfTheme: PdfTheme;
  rowsPerPage: number;
  logoUrl?: string;
  duration?: string;
}

const CommonReportPDF = React.forwardRef<HTMLDivElement, CommonReportPDFProps>(
  ({ title, shopName, generatedBy, generatedOn, summary, columns, data, totalCount, pdfTheme, rowsPerPage, logoUrl, duration }, ref) => {
    
    // Chunk the data according to rowsPerPage
    const chunks: any[][] = [];
    if (data.length === 0) {
      chunks.push([]);
    } else {
      for (let i = 0; i < data.length; i += rowsPerPage) {
        chunks.push(data.slice(i, i + rowsPerPage));
      }
    }
    
    const totalPages = chunks.length;

    return (
      <Box 
        ref={ref}
        sx={{ 
          bgcolor: '#ffffff',
          width: '210mm',
          margin: '0 auto',
          fontFamily: 'sans-serif',
          color: pdfTheme.text,
          fontSize: '10px',
          boxSizing: 'border-box'
        }}
      >
        <GlobalStyles styles={`
          @media print {
            @page {
              size: A4 portrait;
              margin: 15mm;
            }
            body {
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
          }
        `} />
        
        {chunks.map((chunk, index) => {
          const isFirstPage = index === 0;
          const currentPage = index + 1;
          
          return (
            <Box 
              key={index}
              sx={{
                minHeight: '297mm', // Approximate A4 height
                padding: '15mm',
                display: 'flex',
                flexDirection: 'column',
                boxSizing: 'border-box',
                pageBreakAfter: currentPage < totalPages ? 'always' : 'auto',
                breakAfter: currentPage < totalPages ? 'page' : 'auto',
              }}
            >
              {isFirstPage ? (
                <>
                  <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <ReportHeader title={title} shopName={shopName} pdfTheme={pdfTheme} logoUrl={logoUrl} />
                    <ReportInfo generatedOn={generatedOn} generatedBy={generatedBy} pdfTheme={pdfTheme} duration={duration} />
                  </Box>
                  <ReportSummary summary={summary} pdfTheme={pdfTheme} />
                  <Box sx={{ mb: 1, fontSize: '9px', fontWeight: 'bold' }}>
                    Total No. of entries: {totalCount}
                  </Box>
                </>
              ) : null}

              <Box sx={{ flexGrow: 1 }}>
                <ReportTable 
                  columns={columns} 
                  data={chunk} 
                  pdfTheme={pdfTheme} 
                  title={title} 
                  shopName={shopName}
                  showCompactHeader={!isFirstPage} 
                />
              </Box>

              {/* Explicit Footer with Dynamic Page Numbers */}
              <Box sx={{ 
                mt: 'auto', 
                pt: 1, 
                borderTop: `1px solid ${pdfTheme.border}`,
                display: 'flex',
                justifyContent: 'end',
                alignItems: 'end',
                fontSize: '9px',
                color: pdfTheme.secondaryText || pdfTheme.text
              }}>
                <Box sx={{ fontWeight: 'bold' }}>Page {currentPage} of {totalPages}</Box>
              </Box>
            </Box>
          );
        })}
      </Box>
    );
  }
);

CommonReportPDF.displayName = 'CommonReportPDF';

export default CommonReportPDF;
