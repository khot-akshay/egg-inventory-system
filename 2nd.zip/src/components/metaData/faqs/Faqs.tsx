import { Box, Button, Card, Grid, Stack, Switch, Tooltip } from '@mui/material'
import { GridCellParams, GridColDef } from '@mui/x-data-grid'
import React, { useEffect, useState } from 'react'
import CommonDatagrid from 'src/components/common/DatagridData.tsx/CommonDatagrid'

import GoBack from 'src/components/common/goBack/GoBackButton';
import axiosInstance from 'src/services/axios'
import Icon from 'src/@core/components/icon'
import DeleteDialogPopup from 'src/components/common/DeletePopup/DeleteModalPopup'
import checkPermission from 'src/configs/CheckPermisstion';
import toast from 'react-hot-toast';
import AddFaqs from './AddFaqs';
import { capitalizeFirstLetter } from 'src/utils/encodeid';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import TextViewDialog from 'src/components/common/viewtext/TextViewDialog';
import SearchInput from 'src/components/common/SearchInput';
import DateFormateComponent from 'src/components/common/dateFormat/DateFromatModule';




const Faqs = () => {
    const [rows, setRows] = useState([])
    const [totalRows, setTotalRows] = useState(0)
    const [loading, setLoading] = useState(true)
    const [pageSize, setPageSize] = useState(10)
    const [page, setPage] = useState(0)
    const [openAdd, setOpenAdd] = useState(false)
    const [openDelete, setOpenDelete] = useState(false)
    const [selectedItem, setSelectedItem] = useState({})
    const [openEdit, setOpenEdit] = useState(false)
    const [searchQuery, setQuery] = useState("");
    const fetchGame = async () => {
        let url = `/api/v1/admin/getAllFaqs?type=faq&pageNo=${page}&limit=${pageSize}`;


        if (searchQuery) {
            url = `${url}&search=${searchQuery}`;
        }


        // Construct the URL with search and type parameters
        setLoading(true)
        try {
            const response = await axiosInstance.get(url)
            setRows(response.data.data.faqs ?? [])
            setTotalRows(response.data.data?.count ?? 0)
        } catch (e) {
            console.log(e)
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchGame()
    }, [page, pageSize, searchQuery])

    const handlePageChange = (newPage: number) => {
        setPage(newPage)
    }

    const handlePageSizeChange = (newPageSize: number) => {
        setPageSize(newPageSize)
    }
    const handleEditClick = (params: GridCellParams) => {
        setSelectedItem(params.row)
        setOpenEdit(true)
    }
    const handleDeleteOpen = (params: GridCellParams) => {
        console.log('Delete Clicked:', params.row)
        setSelectedItem(params.row)
        setOpenDelete(true)
        console.log('Selected Item for delete:', selectedItem)


    }
    const handleSwitchChange = async (event: React.ChangeEvent<HTMLInputElement>, params: GridColDef[]) => {
        const { checked } = event.target;
        try {
            await axiosInstance.post(`/v1/admin/updateAmenities?id=${params.id}`, { is_active: checked })
            fetchGame()
            toast.success('Status updated successfully.')
        } catch (e) {
            toast.error('Failed to set active')
        }
    }
    const columns: GridColDef[] = [
        {
            field: 'id',
            headerName: 'Sr. No.',
            flex: 1,
            minWidth: 100,
            maxWidth: 100,
            sortable: false,
            renderCell: index => {
                const rowIndex = index.api.getRowIndex(index.row.id)
                return page * pageSize + (rowIndex % pageSize) + 1
            },
            hideable: false
        },
        {
            field: 'title',
            headerName: 'Question',
            flex: 1,

            minWidth: 250,
            sortable: false,
            renderCell: (params: GridCellParams) => <div style={{ whiteSpace: 'normal', wordBreak: 'break-word', lineHeight: 1.5 }}>
                {params.row?.title || 'NA'}
            </div>
        },
        // {
        //     field: 'description',
        //     headerName: 'Answer',
        //     flex: 1,

        //     minWidth: 250,
        //     sortable: false,
        //     renderCell: (params: GridCellParams) => <div style={{ whiteSpace: 'normal', wordBreak: 'break-word', lineHeight: 1.5 }}>
        //         {params.row?.description || 'NA'}
        //     </div>
        // },
        // {
        //     field: 'description',
        //     headerName: 'Answer',
        //     flex: 1,
        //     minWidth: 250,
        //     sortable: false,
        //     renderCell: (params: GridCellParams) => {
        //         const [open, setOpen] = useState(false);
        //         const text = params.row?.description || 'NA';
        //         const shortText = text.length > 50 ? `${text.substring(0, 50)}...` : text;

        //         return (
        //             <>
        //                 <div
        //                     style={{ whiteSpace: 'normal', wordBreak: 'break-word', lineHeight: 1.5, cursor: 'pointer' }}
        //                     onClick={() => setOpen(true)}
        //                 >
        //                     {shortText}
        //                 </div>

        //                 <TextViewDialog
        //                     open={open}
        //                     onClose={() => setOpen(false)}
        //                     title="Answer"
        //                     content={text}
        //                 />
        //             </>
        //         );
        //     }
        // },
        {
            field: 'description',
            headerName: 'Answer',
            flex: 1,
            minWidth: 250,
            sortable: false,
            renderCell: (params: GridCellParams) => {
                const [open, setOpen] = useState(false);
                const text = params.row?.description || 'NA';
                const maxLength = 85    // Adjust the maximum length as needed;

                const shouldTruncate = text.length > maxLength;
                const displayText = shouldTruncate ? `${text.substring(0, maxLength)}...` : text;

                return (
                    <>
                        <div style={{ whiteSpace: 'normal', wordBreak: 'break-word', lineHeight: 1.5 }}>
                            {displayText}
                            {shouldTruncate && (
                                <span
                                    style={{
                                        color: '#1976d2',
                                        cursor: 'pointer',
                                        marginLeft: 4,
                                        fontWeight: 500,
                                        fontSize: 13
                                    }}
                                    onClick={() => setOpen(true)}
                                >
                                    Read More
                                </span>
                            )}
                        </div>

                        <TextViewDialog
                            open={open}
                            onClose={() => setOpen(false)}
                            title="Answer"
                            content={text}
                        />
                    </>
                );
            }
        },
        {
            field: 'Model Type',
            headerName: 'Panel Type',
            flex: 1,
            minWidth: 250,
            sortable: false,
            renderCell: (params: GridCellParams) => <div style={{ whiteSpace: 'normal', wordBreak: 'break-word', lineHeight: 1.5 }}>
                {/* {params.row?.model_type || 'NA'} */}
<p>
  {params.row?.model_type
    ? capitalizeFirstLetter(params.row.model_type.replace(/_/g, " "))
    : "NA"}
</p>
            </div>
        },
        //   {
        //     field: 'amenity_type',
        //     headerName: 'Amenity Type',
        //     flex: 1,
        //     minWidth: 250,
        //     sortable: false,
        //     renderCell: (params: GridCellParams) => (
        //       <p>{params.row?.amenity_type?.name ? (params.row?.amenity_type?.name) : 'NA'}</p>
        //     )
        //   },
        //   { 
        //     field: 'icon',
        //     headerName: 'Amenity Icon',
        //     flex: 1,
        //     minWidth: 250,
        //     sortable: false,
        //     renderCell: (params: GridCellParams) => (
        //       <Icon icon={params?.row?.icon ? params?.row?.icon : 'mdi:home-plus-outline'}/>
        //     )
        //   },
        //   {
        //     field: 'status',
        //     headerName: 'Status',
        //     minWidth: 150,
        //     sortable: false,
        //     renderCell: (params: GridCellParams) => (
        //         <Stack direction='row' alignItems='center' spacing={5}>

        //             <p>{params.row.is_active == '1' ? 'Active' : 'In-active'}</p>
        //             <Switch checked={params.row.is_active == '1' ? true : false} onChange={(event) => handleSwitchChange(event, params.row)} />
        //         </Stack>
        //     ),
        //     flex: 1,
        // },

        {
            field: 'created_at',
            headerName: 'Created Date',
            flex: 1,
            minWidth: 150,
            sortable: false,
            renderCell: (params: GridCellParams) => (
                <DateFormateComponent date={params.row?.created_at ?? ''} />
            )
        },

        {
            field: 'actions',
            headerName: 'Actions',
            minWidth: 150,
            sortable: false,
            flex: 1,
            renderCell: (params: GridCellParams) => (
                <>
                    {/* {checkPermission('update_faqs') && ( */}

                        <Tooltip title='Update FAQs.' placement='bottom'>
                            <Button sx={{ color: '#84919d', margin: '-10px' }} onClick={() => handleEditClick(params)}>
                                <Icon icon={'circum:edit'} fontSize={24} />
                            </Button>
                        </Tooltip>
                    {/* )} */}

                    {/* {checkPermission('delete_faqs') && ( */}

                        <Tooltip title='Delete FAQs.' placement='bottom'>
                            <Button
                                style={{ color: '#84919d', margin: '-10px' }}
                                onClick={() => handleDeleteOpen(params)}
                            >
                                <Icon icon={'ic:outline-delete'} fontSize={24} color='#FC4E4E' />
                            </Button>
                        </Tooltip>
                    {/* )} */}

                </>
            ),
        },
    ]
    const handleSearch = (query) => {
        setQuery(query);
    };

    return (
        <>
            <Card sx={{ p: 5 }}>
                <Box display="flex" justifyContent="space-between" alignItems="center" flexWrap="wrap" sx={{ mb: 3 }}>
                    {/* Left Side: Back Button and Title */}
                    <Box display="flex" alignItems="center" gap={2}>
                        <GoBack label={'FAQs'} isBack={false} />
                    </Box>

                    {/* Right Side: Search and Add Button */}
                    <Box display="flex" alignItems="center" gap={2} flexWrap="wrap">
                        <Grid item xs={12} sm="auto">
                            <SearchInput handleSearch={handleSearch} placeHolder="Search..." />

                        </Grid>
                        {/* {checkPermission('add_faqs') && ( */}
                            <Grid item xs={12} sm="auto">
                                <Button onClick={() => setOpenAdd(true)} variant='contained'>
                                    Add FAQs <AddCircleOutlineIcon sx={{ ml: 1 }} />
                                </Button>
                            </Grid>
                        {/* )} */}
                    </Box>

                </Box>
                <CommonDatagrid
                    totalRows={totalRows}
                    pageSize={pageSize}
                    currentPage={page}
                    handleChangePage={handlePageChange}
                    handleChangeRowsPerPage={handlePageSizeChange}
                    columns={columns}
                    rows={rows}
                    checkboxSelection={false}
                    loading={loading}
                />
            </Card>
            {openAdd && <AddFaqs open={openAdd} handleClose={() => setOpenAdd(false)} fetchData={fetchGame} />}
            {openDelete && (
                <DeleteDialogPopup show={openDelete} handleclose={() => setOpenDelete(false)} selectedItems={selectedItem.id}
                    fetchData={fetchGame}
                    label={'Are you sure! You want to delete.'} apiUrl={'api/v1/admin/deleteFaq?type=faq&id='} />
            )}
            {openEdit && (
                <AddFaqs open={openEdit} handleClose={() => setOpenEdit(false)}
                    fetchData={fetchGame}
                    selectedItem={selectedItem} />
            )}
        </>
    )
}

export default Faqs
