class LocalCategory{
  public getCategoryData(){

  }
}
